/**
 * Codelitix — Cartly Frontend v5.3.
 *
 * Fixes applied in v5.3:
 *   Auto-open (full-page reload) — Single product page uses an HTML form submit
 *   which causes a full page reload; the added_to_cart JS event never fires.
 *   Fix: detect ?added-to-cart= URL param on page load (Pass A) and a
 *   sessionStorage flag set just before form submit (Pass B for clean-URL
 *   redirects). Both paths call openDrawer() on the next page load.
 *
 *   Auto-open key mismatch — admin checkbox saved as 'auto_open' but PHP
 *   checked 'auto_open_atc'. Fixed in class-cartly-core.php to read both keys.
 *
 * Fixes applied in v5.2:
 *   updateReward() — removed erroneous D.shipWrap.removeClass.
 *   initTriggers() — added mobile_enabled and exit_devices guards.
 *
 * @package Cartly
 * @author  codelitix
 */

( function ( $ ) {
	'use strict';
	if ( 'undefined' === typeof CartlyConfig ) {
		return;
	}

	/* ─────────────────────────────────────────────────────────
		CONFIG & STATE  (safe to init immediately — no DOM needed)
	───────────────────────────────────────────────────────── */
	var C = CartlyConfig;
	var S = {
		open: false,
		cdStarted: false,
		cdTimer: null,
		cdSecs: ( parseInt( C.countdown_mins ) || 10 ) * 60,
		exitBound: false,
		satcQty: 1,
		lastRaw: 0
	};

	/* ─────────────────────────────────────────────────────────
		DOM CACHE — declared here, populated in $(function(){})
		CRITICAL: must NOT be populated until DOMContentLoaded
		because the drawer HTML is injected AFTER the script tag.
	───────────────────────────────────────────────────────── */
	var D = {};

	/* ═════════════════════════════════════════════════════════
		DRAWER OPEN / CLOSE
	═════════════════════════════════════════════════════════ */
	function openDrawer() {
		if ( S.open ) {
			return;
		}
		S.open = true;
		D.overlay.addClass( 'is-open' );
		D.drawer.addClass( 'is-open' ).attr( 'aria-hidden', 'false' );
		$( 'body' ).addClass( 'cly-open' );
		D.stickyBar.removeClass( 'is-visible' );
		fetchCart();
		if ( C.countdown_enabled && ! S.cdStarted ) {
			startCountdown();
		}
	}

	function closeDrawer() {
		if ( ! S.open ) {
			return;
		}
		S.open = false;
		D.overlay.removeClass( 'is-open' );
		D.drawer.removeClass( 'is-open' ).attr( 'aria-hidden', 'true' );
		$( 'body' ).removeClass( 'cly-open' );
		if ( 0 < parseInt( D.count.text() ) && C.sticky_bar ) {
			showStickyBar();
		}
	}

	/* ═════════════════════════════════════════════════════════
		AJAX HELPER
	═════════════════════════════════════════════════════════ */
	function ajax( action, data, cb ) {
		$.ajax(
			{
				url: C.ajax_url,
				method: 'POST',
				data: $.extend( { action: action, nonce: C.nonce }, data ),
				success: cb,
				error: function ( jqXHR ) {
					var resp = jqXHR.responseJSON;
					if ( resp && resp.data && resp.data.message ) {
						cb( resp );
					} else {
						cb( { success: false, data: { message: 'Network error.' } } );
					}
				}
			}
		);
	}

	/* ═════════════════════════════════════════════════════════
		FETCH & RENDER CART
	═════════════════════════════════════════════════════════ */
	function fetchCart() {
		D.skeleton.show();
		D.items.empty();
		D.empty.hide();
		D.ft.hide();
		ajax(
			'cartly_get_cart',
			{},
			function ( res ) {
				D.skeleton.hide();
				if ( ! res.success || ! res.data ) {
					showEmpty();
					return;
				}
				renderCart( res.data );
			}
		);
	}

	function renderCart( data ) {
		var items = data.items || [];
		S.lastRaw = parseFloat( data.subtotal_raw ) || 0;

		setCount( data.count || 0 );
		setSubtotal( data.subtotal_html || '', S.lastRaw );

		if ( ! items.length ) {
			showEmpty();
			return;
		}

		D.empty.hide();
		D.items.empty();
		items.forEach(
			function ( item ) {
				D.items.append( buildItem( item ) );
			}
		);
		D.ft.show();
		if ( ! C.disable_anim ) {
			animItems();
		}

		updateShipBar( S.lastRaw, data.shipping_goal, data.shipping_msg, data.shipping_success );
		updateGoals( S.lastRaw, data.goals || [] );
		updateReward( S.lastRaw, data.reward_goal, data.reward_text );
		updateCoupons( data.coupons || [] );
		loadUpsells();
	}

	function showEmpty() {
		D.items.empty();
		D.empty.show();
		D.ft.hide();
		D.upsells.hide();
		D.stickyBar.removeClass( 'is-visible' );
	}

	/* ─── Build a single cart item row ─────────────────── */
	function buildItem( item ) {
		var img = item.thumb ?
		'<img src="' +
		x( item.thumb ) +
		'" alt="' +
		x( item.name ) +
		'" class="cly-item__img" loading="lazy" width="72" height="72">' :
		'<div class="cly-item__img cly-item__img--ph"></div>';

		var lowBadge = item.low_stock ? '<span class="cly-item__low">Low stock</span>' : '';

		return $( '<li class="cly-item"></li>' ).html(
			[
			img,
			'<div class="cly-item__info">',
			'<a href="' + x( item.permalink ) + '" class="cly-item__name">' + x( item.name ) + '</a>',
			item.variation ? '<p class="cly-item__meta">' + x( item.variation ) + '</p>' : '',
			lowBadge,
			'<div class="cly-item__row">',
			'<div class="cly-qty" data-key="' + x( item.key ) + '">',
			'<button class="cly-qty__btn" data-dir="-1" aria-label="Decrease">−</button>',
			'<span class="cly-qty__val">' + parseInt( item.qty ) + '</span>',
			'<button class="cly-qty__btn" data-dir="1"  aria-label="Increase">+</button>',
			'</div>',
			'<span class="cly-item__price">' + item.line_total_html + '</span>',
			'</div>',
			'</div>',
			'<button class="cly-item__rm" data-key="' + x( item.key ) + '" aria-label="Remove">',
			'<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
			'</button>'
			].join( '' )
		);
	}

	function animItems() {
		D.items.find( '.cly-item' ).each(
			function ( i, el ) {
				$( el ).css( { opacity: 0, transform: 'translateY(8px)' } );
				setTimeout(
					function () {
						$( el ).css( { transition: 'opacity .25s, transform .25s', opacity: 1, transform: 'none' } );
					},
					i * 50
				);
			}
		);
	}

	/* ═════════════════════════════════════════════════════════
		FEATURE 2: SMART UPSELL ENGINE
	═════════════════════════════════════════════════════════ */
	function loadUpsells() {
		if ( ! D.upsells.length ) {
			return;
		}
		ajax(
			'cartly_get_upsells',
			{},
			function ( res ) {
				var prods = res.success && Array.isArray( res.data ) ? res.data : [];
				if ( ! prods.length ) {
					D.upsells.hide();
					return;
				}
				D.upsells.show();
				if ( C.upsells_fbt_enabled && prods.length ) {
					D.upsellTitle.text( C.upsells_fbt_title || 'Frequently Bought Together' );
				}
				D.upsellList.empty();
				prods.forEach(
					function ( p ) {
						var badge = p.badge ? '<span class="cly-upsell__badge">' + x( p.badge ) + '</span>' : '';
						var stars = '';
						if ( 0 < parseFloat( p.rating ) ) {
								stars = '<div class="cly-upsell__stars">';
							for ( var i = 1; 5 >= i; i++ ) {
								stars += '<span style="color:' + ( i <= p.rating ? '#f59e0b' : '#d1d5db' ) + '">★</span>';
							}
							stars += '</div>';
						}
						var btn =
						'variable' === p.type ?
						'<a href="' + x( p.permalink ) + '" class="cly-upsell__btn cly-upsell__btn--ghost">Options →</a>' :
						'<button class="cly-upsell__btn">+ Add</button>';
						D.upsellList.append(
							'<div class="cly-upsell" data-id="' +
							p.id +
							'" data-type="' +
							x( p.type ) +
							'">' +
							'<div class="cly-upsell__img-wrap"><img src="' +
							x( p.thumb ) +
							'" alt="' +
							x( p.name ) +
							'" class="cly-upsell__img" loading="lazy">' +
							badge +
							'</div>' +
							'<div class="cly-upsell__name">' +
							x( p.name ) +
							'</div>' +
							stars +
							'<div class="cly-upsell__price">' +
							p.price +
							'</div>' +
							btn +
							'</div>'
						);
					}
				);
			}
		);
	}

	/* ═════════════════════════════════════════════════════════
		COUPON
	═════════════════════════════════════════════════════════ */
	function applyCoupon() {
		var code = D.coupInp.val().trim();
		if ( ! code ) {
			return;
		}
		D.coupApply.text( '…' ).prop( 'disabled', true );
		ajax(
			'cartly_apply_coupon',
			{ coupon: code },
			function ( res ) {
				D.coupApply.text( 'Apply' ).prop( 'disabled', false );
				if ( res.success ) {
					D.coupMsg.removeClass( 'err' ).text( '✓ Coupon applied!' ).show();
					D.coupInp.val( '' );
					D.coupBody.slideUp( 180 );
					if ( res.data ) {
						renderCart( res.data );
					}
					setTimeout(
						function () {
							D.coupMsg.hide();
						},
						3000
					);
				} else {
					var msg = res.data && res.data.message ? res.data.message : 'Invalid coupon.';
					D.coupMsg.addClass( 'err' ).text( msg ).show();
				}
			}
		);
	}

	/* ═════════════════════════════════════════════════════════
		UI UPDATERS
	═════════════════════════════════════════════════════════ */
	function setCount( n ) {
		D.count.text( n );
		D.floatBtn.find( '.cly-btn-count' ).text( n ).attr( 'data-count', n );
	}

	function setSubtotal( html, raw ) {
		D.sub.html( html );
		D.checkSub.html( html );
		if ( C.sticky_bar && ! S.open && 0 < parseInt( D.count.text() ) ) {
			showStickyBar();
		}
	}

	function showStickyBar() {
		if ( ! D.stickyBar.length ) {
			return;
		}
		var cnt = D.count.text();
		D.stickySumm.html( cnt + ' ' + ( 1 === parseInt( cnt ) ? 'item' : 'items' ) + ' &nbsp;·&nbsp; ' + D.sub.html() );
		D.stickyBar.addClass( 'is-visible' );
	}

	function updateShipBar( raw, goal, msg, success ) {
		if ( ! D.shipWrap.length ) {
			return;
		}
		goal = parseFloat( goal || C.shipping_goal ) || 0;
		if ( ! goal ) {
			D.shipWrap.hide();
			return;
		}
		D.shipWrap.show();
		var pct = Math.min( 100, ( raw / goal ) * 100 );
		D.shipFill.css( 'width', pct + '%' ).attr( 'aria-valuenow', pct.toFixed( 0 ) );
		if ( raw >= goal ) {
			D.shipMsg.html( C.shipping_success || success || '🎉 Free Shipping unlocked!' );
			D.shipFill.css( { width: '100%', background: 'var(--cly-grn, #10b981)' } );
			D.shipWrap.addClass( 'is-success' );
		} else {
			D.shipWrap.removeClass( 'is-success' );
			var rem = '<strong>' + sym( goal - raw ) + '</strong>';
			D.shipMsg.html( ( C.shipping_msg || msg || 'Spend {amount} more' ).replace( '{amount}', rem ) );
			D.shipFill.css( 'background', '' );
		}
	}

	function updateGoals( raw, goalsArr ) {
		if ( ! D.goals.length || ! goalsArr.length ) {
			return;
		}
		D.goals.show();
		var maxGoal = 0,
		next        = null;
		D.goals.find( '.cly-goals__marker' ).each(
			function ( i ) {
				var g = goalsArr[i];
				if ( ! g ) {
					return;
				}
				var amount = parseFloat( g.amount ) || 0;
				if ( amount > maxGoal ) {
					maxGoal = amount;
				}
				if ( raw >= amount ) {
					$( this ).addClass( 'is-reached' );
				} else {
					$( this ).removeClass( 'is-reached' );
					if ( ! next || amount < next.amount ) {
						next = { amount: amount, label: g.label, icon: g.icon };
					}
				}
			}
		);
		var pct = 0 < maxGoal ? Math.min( 100, ( raw / maxGoal ) * 100 ) : 0;
		D.goalsFill.css( 'width', pct + '%' );
		if ( next ) {
			D.goalsMsg.html(
				'Add <strong>' +
				sym( next.amount - raw ) +
				'</strong> more to unlock ' +
				( next.icon || '' ) +
				' <b>' +
				x( next.label ) +
				'</b>'
			);
		} else {
			D.goalsMsg.html( '🎉 All rewards unlocked!' );
		}
	}

	function updateReward( raw, goal, text ) {
		if ( ! D.reward.length ) {
			return;
		}
		goal = parseFloat( goal || C.reward_goal ) || 0;
		if ( ! goal ) {
			D.reward.hide();
			return;
		}
		D.reward.show();
		var pct = Math.min( 100, ( raw / goal ) * 100 );
		D.rwFill.css( 'width', pct + '%' );
		if ( raw >= goal ) {
			D.reward.addClass( 'is-success' );
			D.rwMsg.html( '🎉 Reward unlocked!' );
		} else {
			D.reward.removeClass( 'is-success' );
			var rem = '<strong>' + sym( goal - raw ) + '</strong>';
			D.rwMsg.html( ( C.reward_text || text || 'Add {amount} more' ).replace( '{amount}', rem ) );
		}
	}

	function updateCoupons( coupons ) {
		D.coupTags.empty();
		( coupons || []).forEach(
			function ( c ) {
				D.coupTags.append(
					'<span class="cly-coupon__tag">' +
					x( c.code ) +
					' <button class="cly-coupon__remove" data-code="' +
					x( c.code ) +
					'" aria-label="Remove coupon">✕</button>' +
					'</span>'
				);
			}
		);
	}

	/* ═════════════════════════════════════════════════════════
		FEATURE 3: COUNTDOWN TIMER
	═════════════════════════════════════════════════════════ */
	function startCountdown() {
		if ( S.cdStarted || ! D.countdown.length ) {
			return;
		}
		S.cdStarted = true;
		D.countdown.show();
		S.cdTimer = setInterval( tick, 1000 );
		tick();
	}

	function tick() {
		if ( 0 >= S.cdSecs ) {
			clearInterval( S.cdTimer );
			return;
		}
		S.cdSecs--;
		var m = Math.floor( S.cdSecs / 60 );
		var s = S.cdSecs % 60;
		updateDigit( D.timerMin, pad( m ) );
		updateDigit( D.timerSec, pad( s ) );
	}

	function updateDigit( $el, val ) {
		if ( $el.text() !== val ) {
			$el.text( val ).addClass( 'tick' );
			setTimeout(
				function () {
					$el.removeClass( 'tick' );
				},
				150
			);
		}
	}

	function pad( n ) {
		return 10 > n ? '0' + n : String( n );
	}

	/* ═════════════════════════════════════════════════════════
		FEATURE 1: STICKY ADD-TO-CART BAR
	═════════════════════════════════════════════════════════ */
	function initStickyAtc() {
		if ( ! D.satc.length ) {
			return;
		}

		var $anchor = $( 'form.cart' ).first();
		if ( ! $anchor.length ) {
			$anchor = $( '.single_add_to_cart_button' ).first();
		}
		if ( ! $anchor.length ) {
			return;
		}

		var visible = true;
		$( window ).on(
			'scroll.satc resize.satc',
			function () {
				if ( ! $anchor.length ) {
					return;
				}
				var rect    = $anchor[0].getBoundingClientRect();
				var nowGone = 60 > rect.bottom;
				if ( nowGone !== ! visible ) {
					visible = ! nowGone;
					D.satc.toggleClass( 'is-visible', ! visible );
				}
			}
		);

		D.satc.on(
			'click',
			'.cly-satc__qty-btn',
			function () {
				S.satcQty = Math.max( 1, S.satcQty + parseInt( $( this ).data( 'dir' ) ) );
				$( '#cly-satc-qty' ).text( S.satcQty );
			}
		);

		D.satcBtn.on(
			'click',
			function ( e ) {
				e.preventDefault();
				var $b    = $( this );
				var pid   = $b.data( 'pid' );
				var isVar = $b.data( 'var' );

				if ( isVar ) {
					$( 'html,body' ).animate( { scrollTop: $anchor.offset().top - 80 }, 380 );
					D.satc.removeClass( 'is-visible' );
					return;
				}

				$b.addClass( 'loading' ).html(
					'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg> Adding…'
				);

				ajax(
					'cartly_add_to_cart',
					{ product_id: pid, qty: S.satcQty },
					function ( res ) {
						if ( res.success ) {
							$b.removeClass( 'loading' ).addClass( 'added' ).html( '✓ Added to Cart!' );
							if ( res.data ) {
								renderCart( res.data );
							}
							setTimeout( openDrawer, 280 );
							setTimeout(
								function () {
									$b.removeClass( 'added' ).html(
										'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg> ' +
										x( C.satc_text || 'Add to Cart' )
									);
								},
								3200
							);
						} else {
							$b.removeClass( 'loading' ).text( 'Error — Try Again' );
							setTimeout(
								function () {
									$b.html(
										'<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg> ' +
										x( C.satc_text || 'Add to Cart' )
									);
								},
								2000
							);
						}
					}
				);
			}
		);
	}

	/* ═════════════════════════════════════════════════════════
		FEATURE 6: SMART TRIGGERS
	═════════════════════════════════════════════════════════ */
	function initTriggers() {

		// codelitix – Fix #4: If mobile_enabled is false and we're on mobile, suppress triggers.
		// We detect mobile via screen width (< 768px) as a JS-side guard to complement
		// the PHP-side wp_is_mobile() check.
		var isMobile = 768 > window.innerWidth;
		if ( ! C.mobile_enabled && isMobile ) {
			return;
		}

		switch ( C.trigger_event ) {
			case 'scroll':
				var pctTarget = parseInt( C.trigger_scroll ) || 30;
				$( window ).one(
					'scroll.cly-trigger',
					function check() {
						var scrolled = window.scrollY;
						var total    = document.body.scrollHeight - window.innerHeight;
					if ( 0 < total && ( scrolled / total ) * 100 >= pctTarget ) {
						openDrawer();
					} else {
						$( window ).one( 'scroll.cly-trigger', check );
					}
					}
				);
			break;

			case 'delay':
				setTimeout(
					function () {
						if ( ! S.open ) {
							openDrawer();
						}
					},
					( parseInt( C.trigger_delay ) || 3 ) * 1000
				);
			break;
		}

		if ( C.trigger_exit_intent && ! S.exitBound ) {

			// codelitix – Fix #6: honour exit_devices setting.
			// 'desktop' (default) = only fire on non-mobile; 'all' = fire everywhere.
			var exitDevices    = C.exit_devices || 'desktop';
			var shouldBindExit = 'all' === exitDevices || ! isMobile;

			if ( shouldBindExit ) {
				S.exitBound = true;
				var fired   = false;
				document.addEventListener(
					'mouseleave',
					function ( e ) {
						if ( fired || S.open || 5 < e.clientY ) {
							return;
						}
						fired = true;
						D.floatBtn.addClass( 'exit-pulse' );
						setTimeout(
							function () {
								D.floatBtn.removeClass( 'exit-pulse' );
								if ( ! S.open ) {
									openDrawer();
								}
							},
							parseInt( C.trigger_exit_delay ) || 500
						);
					}
				);
			}
		}
	}

	/* ═════════════════════════════════════════════════════════
		UTILS
	═════════════════════════════════════════════════════════ */
	function x( str ) {
		return String( str || '' )
		.replace( /&/g, '&amp;' )
		.replace( /</g, '&lt;' )
		.replace( />/g, '&gt;' )
		.replace( /"/g, '&quot;' );
	}
	function sym( amount ) {
		return ( C.currency_symbol || '$' ) + parseFloat( amount ).toFixed( 2 );
	}

	function pulseBtn() {
		if ( ! D.floatBtn.length || C.disable_anim ) {
			return;
		}
		var cls = 'shake' === C.button_animation ? 'cly-btn--shake' : 'cly-btn--bounce';
		D.floatBtn.addClass( cls );
		setTimeout(
			function () {
				D.floatBtn.removeClass( cls );
			},
			700
		);
	}

	/* ═════════════════════════════════════════════════════════
		INIT — everything that touches the DOM lives here.
		The drawer HTML is rendered at wp_footer priority 99.
		Scripts fire at wp_footer priority 20 (before the HTML).
		$(document).ready() waits for DOMContentLoaded which fires
		AFTER all HTML is parsed — so D and bindings are safe here.
	═════════════════════════════════════════════════════════ */
	$(
		function () {

			/* ── Populate DOM cache ── */
			D.overlay  = $( '#cly-overlay' );
			D.drawer   = $( '#cly-drawer' );
			D.close    = $( '#cly-close' );
			D.body     = $( '#cly-body' );
			D.skeleton = $( '#cly-skeleton' );
			D.empty    = $( '#cly-empty' );
			D.items    = $( '#cly-items' );
			D.ft       = $( '#cly-ft' );
			D.count    = $( '#cly-count' );
			D.sub      = $( '#cly-subtotal' );
			D.checkSub = $( '#cly-checkout-sub' );

			// Shipping bar.
			D.shipWrap = $( '#cly-ship' );
			D.shipFill = $( '#cly-ship-fill' );
			D.shipMsg  = $( '#cly-ship-msg' );

			// Goals.
			D.goals     = $( '#cly-goals' );
			D.goalsFill = $( '#cly-goals-fill' );
			D.goalsMsg  = $( '#cly-goals-msg' );

			// Reward.
			D.reward = $( '#cly-reward' );
			D.rwMsg  = $( '#cly-reward-msg' );
			D.rwFill = $( '#cly-reward-fill' );

			// Countdown.
			D.countdown = $( '#cly-countdown' );
			D.timerMin  = $( '#cly-timer-min' );
			D.timerSec  = $( '#cly-timer-sec' );

			// Coupon.
			D.coupTog   = $( '#cly-coup-tog' );
			D.coupBody  = $( '#cly-coup-body' );
			D.coupInp   = $( '#cly-coup-inp' );
			D.coupApply = $( '#cly-coup-apply' );
			D.coupMsg   = $( '#cly-coup-msg' );
			D.coupTags  = $( '#cly-coup-tags' );

			// Upsells.
			D.upsells     = $( '#cly-upsells' );
			D.upsellList  = $( '#cly-upsells-list' );
			D.upsellTitle = $( '#cly-upsells-title' );

			// Buttons.
			D.floatBtn   = $( '#cly-float-btn' );
			D.stickyBar  = $( '#cly-sticky-bar' );
			D.stickySumm = $( '#cly-sticky-summary' );
			D.stickyOpen = $( '#cly-sticky-open' );
			D.contEmpty  = $( '#cly-continue-empty' );
			D.cont       = $( '#cly-continue' );

			// Sticky ATC.
			D.satc    = $( '#cly-satc' );
			D.satcBtn = $( '#cly-satc-btn' );

			/* ── Preset body class ── */
			$( 'body' ).addClass( 'cly-preset-' + ( C.preset || 'modern' ) );

			/* ── Core open/close bindings ── */
			D.overlay.on( 'click', closeDrawer );
			D.close.on( 'click', closeDrawer );
			D.cont.on( 'click', closeDrawer );
			D.contEmpty.on( 'click', closeDrawer );

			$( document ).on(
				'keydown',
				function ( e ) {
					if ( 'Escape' === e.key && S.open ) {
						closeDrawer();
					}
				}
			);

			/* Float button — also use event delegation as belt-and-suspenders */
			$( document ).on( 'click', '#cly-float-btn', openDrawer );
			D.stickyOpen.on( 'click', openDrawer );

			/* ── Mobile swipe-to-close ── */
			var tx = 0,
			ty     = 0;
			D.drawer
			.on(
				'touchstart',
				function ( e ) {
					tx = e.originalEvent.changedTouches[0].screenX;
					ty = e.originalEvent.changedTouches[0].screenY;
				}
			)
			.on(
				'touchend',
				function ( e ) {
					var dx      = e.originalEvent.changedTouches[0].screenX - tx;
					var dy      = e.originalEvent.changedTouches[0].screenY - ty;
					var isRight = D.drawer.hasClass( 'cly-drawer--right' );
					if ( 80 < Math.abs( dy ) && dy > Math.abs( dx ) ) {
							closeDrawer();
							return;
					}
					if ( 60 < Math.abs( dx ) && Math.abs( dx ) > Math.abs( dy ) ) {
						if ( ( isRight && 0 < dx ) || ( ! isRight && 0 > dx ) ) {
							closeDrawer();
						}
					}
				}
			);

			/* ── Cart item qty & remove (delegated on #cly-items) ── */
			D.items.on(
				'click',
				'.cly-qty__btn',
				function () {
					var $wrap = $( this ).closest( '.cly-qty' );
					var key   = $wrap.data( 'key' );
					var cur   = parseInt( $wrap.find( '.cly-qty__val' ).text() ) || 1;
					var nq    = Math.max( 0, cur + parseInt( $( this ).data( 'dir' ) ) );
					$wrap.find( '.cly-qty__val' ).text( nq );

					// Micro-interaction: qty pulse + price fade.
					$wrap.addClass( 'cly-qty--pulse' );
					setTimeout(
						function () {
							$wrap.removeClass( 'cly-qty--pulse' );
						},
						160
					);
					$wrap.closest( '.cly-item' ).find( '.cly-item__price' ).addClass( 'updating' );
					$wrap.css( 'opacity', 0.5 );
					ajax(
						'cartly_update_cart',
						{ key: key, qty: nq },
						function ( res ) {
							$wrap.css( 'opacity', 1 );
							$wrap.closest( '.cly-item' ).find( '.cly-item__price' ).removeClass( 'updating' );
							if ( res.success && res.data ) {
								renderCart( res.data );
							}
						}
					);
				}
			);

			D.items.on(
				'click',
				'.cly-item__rm',
				function () {
					var key = $( this ).data( 'key' );
					$( this ).closest( '.cly-item' ).css( { opacity: 0.3, pointerEvents: 'none' } );
					ajax(
						'cartly_remove_item',
						{ key: key },
						function ( res ) {
							if ( res.success && res.data ) {
									renderCart( res.data );
							}
						}
					);
				}
			);

			/* ── Upsell add-to-cart ── */
			D.upsells.on(
				'click',
				'.cly-upsell__btn:not(.cly-upsell__btn--ghost)',
				function () {
					var $c = $( this ).closest( '.cly-upsell' ),
					$b     = $( this );
					$b.text( 'Adding…' ).prop( 'disabled', true );
					ajax(
						'cartly_add_to_cart',
						{ product_id: $c.data( 'id' ), qty: 1 },
						function ( res ) {
							if ( res.success ) {
									$b.text( '✓ Added' ).addClass( 'added' );
								if ( res.data ) {
									renderCart( res.data );
								}
								setTimeout(
									function () {
										$b.text( '+ Add' ).removeClass( 'added' ).prop( 'disabled', false );
									},
									2500
								);
							} else {
								$b.text( '+ Add' ).prop( 'disabled', false );
							}
						}
					);
				}
			);

			/* ── Coupon ── */
			D.coupTog.on(
				'click',
				function () {
					var open = D.coupBody.is( ':visible' );
					D.coupBody.slideToggle( 180 );
					D.coupTog.attr( 'aria-expanded', ! open );
					D.coupTog.find( '.cly-coupon__arr' ).css( 'transform', open ? '' : 'rotate(180deg)' );
				}
			);

			D.coupApply.on( 'click', applyCoupon );
			D.coupInp.on(
				'keydown',
				function ( e ) {
					if ( 'Enter' === e.key ) {
						applyCoupon();
					}
				}
			);

			D.coupTags.on(
				'click',
				'.cly-coupon__remove',
				function () {
					var code = $( this ).data( 'code' );
					ajax(
						'cartly_remove_coupon',
						{ coupon: code },
						function ( res ) {
							if ( res.success && res.data ) {
									renderCart( res.data );
							}
						}
					);
				}
			);

			/* ── WooCommerce added_to_cart event (AJAX add-to-cart — shop/archive pages) ── */
			$( document.body ).on(
				'added_to_cart',
				function ( e, frags ) {
					if ( frags ) {
						$.each(
							frags,
							function ( sel, html ) {
								if ( '.cly-cart-count' === sel ) {
									setCount( parseInt( $( html ).text() ) || 0 );
								}
							}
						);
					}
					pulseBtn();
					if ( 'auto_open' === C.trigger_event && ! S.open ) {
						setTimeout( openDrawer, 80 );
					}
				}
			);

			/* ── Auto-open after full-page add-to-cart (single product pages) ──────────
			*
			* On single product pages, WooCommerce submits a standard HTML form and
			* REDIRECTS back — the added_to_cart JS event NEVER fires after a page reload.
			* After the redirect, WC appends ?added-to-cart=ID to the URL.
			*
			* Two-pass strategy so we catch both patterns:
			*   Pass A — URL contains ?added-to-cart=  (WC default redirect)
			*   Pass B — sessionStorage flag set just before a non-AJAX form submit
			*            (catches themes that redirect to a clean URL, stripping the param)
			* ── */
			if ( 'auto_open' === C.trigger_event ) {

					// Pass A: standard WC redirect URL.
					var urlParams  = new URLSearchParams( window.location.search );
					var addedParam = urlParams.get( 'added-to-cart' ) || urlParams.get( 'add-to-cart' );
				if ( addedParam ) {

					// Clean the param from the address bar without a reload.
					try {
						var cleanUrl =
							window.location.pathname +
							( window.location.search
						.replace( /[?&]added-to-cart=[^&]*/g, '' )
						.replace( /[?&]add-to-cart=[^&]*/g, '' )
						.replace( /^&/, '?' ) || '' );
						window.history.replaceState( {}, '', cleanUrl );
					} catch ( e ) {
					}
					setTimeout( openDrawer, 180 );
				}

				// Pass B: sessionStorage flag (set below on form submit).
				try {
					if ( '1' === sessionStorage.getItem( 'cly_atc_pending' ) ) {
						sessionStorage.removeItem( 'cly_atc_pending' );
						setTimeout( openDrawer, 180 );
					}
				} catch ( e ) {
				}

				// Set sessionStorage flag when a non-AJAX add-to-cart form is submitted
				// so the NEXT page load knows to open the drawer (covers clean-URL redirects).
				$( document ).on(
					'submit',
					'form.cart',
					function () {
						try {
							sessionStorage.setItem( 'cly_atc_pending', '1' );
						} catch ( e ) {
						}
					}
				);
			}

			/* ── Smart Triggers & Sticky ATC ── */
			initTriggers();
			initStickyAtc();

			/* ── Restore cart count from WC session ── */
			try {
				if ( 'undefined' !== typeof wc_cart_fragments_params ) {
					var stored = sessionStorage.getItem( wc_cart_fragments_params.fragment_name );
					if ( stored ) {
							var frags = JSON.parse( stored );
						if ( frags && frags['.cly-cart-count']) {
							setCount( parseInt( $( frags['.cly-cart-count'] ).text() ) || 0 );
						}
					}
				}
			} catch ( e ) {
			}
		}
	); // end $(document).ready().
}( jQuery ) );